const TARGET_URL = "https://www.kom.club/?register=true&state=&code=3bf32931c16bb587d93bb8bf2588fb3fdbacf734&scope=";
const BOTAO_SELETOR = ".Button--btn--1i5yb.Button--primary--Phrgk.btn-sm.btn-block.text-footnote.ChallengeJoinButton--button--Q7s71";

function coletarLinks(tabId) {
    // Seu código adaptado para coletar os links dos eventos
    return `
        var lista = window.document.getElementsByClassName('col-sm-6 challenge-list');
        var links = [];
        Array.from(lista).forEach(elemento => {
            let divInterna = elemento.children[0];
            const isElementoVisivel = elemento.offsetHeight;
            const isElementoCardSemAnuncio = divInterna.localName !== 'a' && !divInterna.classList.contains('col-sm-4') && !Boolean(elemento.style['padding-top']);
            if (isElementoVisivel && elemento.childElementCount == 4 && isElementoCardSemAnuncio) {
                const link = elemento.children[0].children[0];
                if (link.tagName === 'A' && link.href) {
                    links.push(link.href);
                }
            }
        });
        links;
    `;
}

browser.browserAction.onClicked.addListener(async () => {
    // Abre a página de eventos
    browser.tabs.create({ url: TARGET_URL }, function(tab) {
        // Aguarda a página carregar
        browser.tabs.onUpdated.addListener(function listener(tabId, info) {
            if (tabId === tab.id && info.status === 'complete') {
                browser.tabs.onUpdated.removeListener(listener);
                // Executa o script para coletar os links
                browser.tabs.executeScript(tab.id, {
                    code: coletarLinks(tab.id)
                }).then(results => {
                    const links = results[0] || [];
                    // Fecha a aba de coleta
                    browser.tabs.remove(tab.id);
                    // Para cada link, abre, executa ação e fecha
                    links.forEach((url, idx) => {
                        setTimeout(() => {
                            browser.tabs.create({ url }, function(newTab) {
                                browser.tabs.onUpdated.addListener(function clickListener(tabId2, info2) {
                                    if (tabId2 === newTab.id && info2.status === 'complete') {
                                        browser.tabs.onUpdated.removeListener(clickListener);
                                        // Clica no botão definido
                                        browser.tabs.executeScript(newTab.id, {
                                            code: `
                                                var btn = document.getElementsByClassName('${BOTAO_SELETOR}');
                                                if(btn) btn.click();
                                            `
                                        }).then(() => {
                                            setTimeout(() => {
                                                browser.tabs.remove(newTab.id);
                                            }, 3000); // tempo para o botão agir
                                        });
                                    }
                                });
                            });
                        }, idx * 4000); // espaça as aberturas para evitar sobrecarga
                    });
                });
            }
        });
    });
});